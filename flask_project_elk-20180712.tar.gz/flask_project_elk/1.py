from elasticsearch import Elasticsearch
import urllib,sys
reload(sys)
sys.setdefaultencoding('utf-8')
from db import mysqlconn
es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
#body={
#    "aggregations": {
#        "user": {
#            "terms": {
#                "field": "response",
#                "size": 10,
#                "order": {
#                    "_count": "desc"
#                }
#            }
#        }
#    }
#}
ccc={
  "query": {
    "match_all": {}
  },
  "aggregations": {
    "avg_grade": {
      "avg": {
        "field": "bytes"
      }
    }
  },
  "aggregations": {
    "min_grade": {
      "min": {
        "field": "bytes"
      }
    }
  },
  "aggregations": {
    "max_grade": {
      "max": {
        "field": "bytes"
      }
    }
  }


}
#body={
     
#    "query":{"terms":{"bytes":['118515']}}

#    }
ccc={
      "aggs": {
             "colors": {
         "terms": {
            "field": "agent.keyword",
            "size": 10,
            "order":{"_count":"desc"}
         }
        }
      }
}
ccc={
  "query": {
    "match_all": {}
  },
  "aggregations": {
    "max_grade": {
      "max": {
        "field": "bytes"
       }
      }
      }

    }
body={
    "aggs" : {
        "grades_stats" : { "stats" : { "field" : "bytes" } }
    }
}
aaa={
    "aggs" : {
        "grades_count" : { "value_count" : { "field" : "clientip.keyword" } } 
    }
}
bbb={
    "query": {
        "match": {
            "clientip": "222.249.170.73" 
        }
    },
    "size": 0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }
}
eee={
  "aggs": {
    "uniq_attr": {
      "cardinality": {
        "field": "clientip.keyword"
      }
    }
  }
}
fff={
    "query": {
        "match_all": {
            
        }
    },
    "size": 0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }
}
ggg={'facets':
    {'tag':
        {'terms':
            {'fields':['verb.keyword','client_ip.keyword'],
              'size':10
           }
        }
    },
    'query':
        {'match_all':{}},
    'size':0
}
hhh={
  "query": {
    "multi_match": {
      "fields":  [ "verb", "response" ],
      
      
    }
  }
}
body={
      "query":{
      "terms":{"clientip":['114.55.15.7','222.249.170.73']}
      },
       "size":0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }

}

##############

iii = {
    "query":{
        "terms":{
            "clientip.keyword":['114.55.15.7','222.249.170.73']
        }
    },
        "aggs": {
        "per_count": {
            "terms": {
                "field": "request.keyword"

            }
        }
    }

}

jjj={ 
      "query":{"match_all":{}}
}
body = {
    "query":{
        "range":{
            "response":{
                "gte":200,       # >=18
                #"lte":504        # <=30
            }
        }
    }
}
jjj = {
    "query":{
        "range":{
            "bytes":{
                "gte":103,
                "lte":1000       # >=18
                        # <=30
            }
        }
    }
}
iii = {
    "query":{
        "terms":{
            "clientip.keyword":['114.55.15.7','222.249.170.73']
        }
    },
        "aggs": {
        "per_count": {
            "terms": {
                "field": "request.keyword"

            }
        }
    }

}
jjj = {
    "query":{
        "range":{
            "@timestamp":{
                "gte":1525795198000,
                "lte":1525831361691       # >=18
                        # <=30
            }
        }

    },
        "aggs": {
        "per_count": {
            "terms": {
                "field": "request.keyword"

            }
        }
    }


}
body = {
    "query":{
        "wildcard":{
            "request.keyword":"*index.php?m=goods&c=search&a=search&keyword=*"
        }
    },
    "aggs":{
    "search_keyword":{
        "terms":{
              "field": "request.keyword",
              "size":2000
            
               }
         }
      }
}


sql="select id as ids,logstash from logstash_list"
result=mysqlconn.mysqlconn(sql)
for line in result:
    print line
    #res=es.search(index='logstash-nginx-access-2018.05.04',doc_type="nginx_access",body=body)
    #res=es.search(index=logstash,doc_type="nginx_access",body=body)
    #for k in res['aggregations']['search_keyword']['buckets']:
    #    name=str(k["key"].split('&keyword=')[1])
    #    urldecodedCmsBody = urllib.unquote(name)
    #    count=k['doc_count']
    #    print id,logstash,urldecodedCmsBody,count
    
    
    
