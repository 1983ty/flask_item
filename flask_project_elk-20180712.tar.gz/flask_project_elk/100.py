from time_strftime import get_transfer
p=get_transfer()
print p.transfer_time()
