from elasticsearch import Elasticsearch
es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
starttime=1525795198000
endtime=1525831361691
body = {
    "query":{
               
        "bool":{


            "must":[
                {
                    "wildcard":{
                        "clientip.keyword":"*"
                    }
                },
                {
                   "match":{
                          "agent":"gy-top-java"
                         }
                },
                {
                   "match":{
                         "request":"/api/shopexapi/"
                         }
                   
                },
                {
                  "term":{
                         "response":200
                        }
                },
                  {
                  "range":{
                        "@timestamp":{
                        "gte":starttime,
                        "lte":endtime       # >=18
                        # <=30
                          }


               }}   
            ]
        }
    },
    "aggs":{
    "search_keyword":{
        "terms":{
              "field": "clientip.keyword",
              "size":10

               }
         }
      }

}

res=es.search(index='logstash-nginx-access-2018.05.*',doc_type="nginx_access",body=body)
print res

