#!/usr/bin/python
#!- coding: utf-8 -
import sys
import os,time
reload(sys)
sys.setdefaultencoding("utf-8")

import csv,codecs
def csv_output(rows):
    #datas = [['姓名', '年龄'],
    #     ['Bob', 14],
    #     ['Tom', 23],
    #     ['Jerry', '18']]
    data=[['关键词','访问次数']]
    for line in rows:
        data.append(line)

    with codecs.open('/home/flask_project_elk/static/download/example.csv', 'w','utf_8_sig') as f:
        writer = csv.writer(f)
        for row in data:
            writer.writerow(row)
if __name__=='__main__':
    csv_download(rows)
