import MySQLdb,hashlib
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
def mysqlconn(sql):
    conn=MySQLdb.connect(host="rr-uf652178gym876t36.mysql.rds.aliyuncs.com",user="www_99gw_net",passwd="sPCc7TpDAYA",db="mall",charset="utf8")
    cur=conn.cursor()
    cur.execute(sql)
    if sql[:6]=="select":
        rows=cur.fetchall()
    else:
        rows=None
        conn.commit()
    cur.close()
    conn.close()
    return rows
if __name__=='__main__':
    password='111111'
    pwd=hashlib.md5(password).hexdigest()
    #sql="insert into userlogin set uname='bob',pwd=md5('111')"
    #sql="select count(*) from `order` where sn > '20180613000000000000' and sn <= '20180614235959999999';"
    sql="select (select sum(real_amount) from `order` where sn like '2018%' and pay_status=1) as a,(select sum(real_amount) from `order` where sn like '201807%' and pay_status=1) as b,(select sum(real_amount) from `order` where sn like '20180702%' and pay_status=1) as c from `order` limit 1"
    rows=mysqlconn(sql)
    print rows[0][0]

