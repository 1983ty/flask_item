import MySQLdb,hashlib
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

def mysqlconn(sql):
    conn=MySQLdb.connect(host="172.19.146.77",user="mall",passwd="mall",db="malllogs",charset="utf8")
    cur=conn.cursor()
    cur.execute(sql)
    if sql[:6]=="select":
        rows=cur.fetchall()
    else:
        rows=None
        conn.commit()
    cur.close()
    conn.close()
    return rows
if __name__=='__main__':
    password='111111'
    pwd=hashlib.md5(password).hexdigest()
    print '..........................',pwd
    #sql="insert into userlogin set uname='bob',pwd=md5('111')"
    sql="select logstash from logstash_list"
    print mysqlconn(sql)


