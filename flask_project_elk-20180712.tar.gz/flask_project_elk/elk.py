#!/usr/bin/python
# -*- encoding: utf-8 -*-
import sys
import json
import urllib2
import re
import MySQLdb,time,datetime
import urllib,sys
reload(sys)
sys.setdefaultencoding('utf-8')
from db import mysqlconn
from elasticsearch import Elasticsearch
def elkconn():
    es=Elasticsearch(['172.19.146.77:9200'])
    return es
def getindexlist():
    urlf=open('es_url.txt','w')
    url='http://172.19.146.77:9200/_cat/indices'
    res=urllib2.urlopen(url)
    res=res.read()
    urlf.write(res)
    urlf.close()
    return urlf
def reades_list():
    logstash_index=[]
    #res=re.findall(r'\w+\-nginx\-\w+\-\d+\.\w+\.\w+',t)
    with open('es_url.txt','r') as fobj:
        for line in fobj:
            line=line.strip()
            line=line.split(' ')[2]
            res=re.findall(r'\w+\-nginx\-\w+\-\d+\.\w+\.\w+',line)
            if len(res)==0:
                continue
            logstash_index.append(res[0])
        return  logstash_index
def get_localtime():
    array_time=time.localtime()
    nowtime=time.strftime("%Y.%m.%d",array_time)
    return  nowtime
def getindex_count():
    indexlist=[]
    es=elkconn()
    urlf=getindexlist()
    nowtime=get_localtime()
    prefix='logstash-nginx-access-' 
    fullfilename=prefix+nowtime
    logstash_index=reades_list()
    for indexname in logstash_index:
        if fullfilename==indexname:
            continue
        sql="select logstash from logstash_list where logstash='%s'" % indexname
        #amount=es.count(index=indexname,doc_type='nginx_access')
        #amount=amount['count']
        #sql="insert into logstash_list set logstash='%s',amount='%s' "  %(indexname,amount)
        rows=mysqlconn.mysqlconn(sql)
        if len(rows)==1:
            pass
        else:
            amount=es.count(index=indexname,doc_type='nginx_access')
            amount=amount['count']
            sql="insert into logstash_list set logstash='%s',amount='%s' "  %(indexname,amount)
            rows=mysqlconn.mysqlconn(sql)
            print sql
            indexlist.append(indexname)
    print indexlist
            

if __name__=='__main__':
    getindex_count()
    get_localtime()
