from elasticsearch import Elasticsearch
import urllib,sys
reload(sys)
sys.setdefaultencoding('utf-8')
from db import mysqlconn
es=Elasticsearch(['172.19.146.77:9200'])

body={
         "query":{"match_all":{}}
}



res=es.count(index='logstash-nginx-access-2018.07.06',doc_type="nginx_access",body=body)

print res
