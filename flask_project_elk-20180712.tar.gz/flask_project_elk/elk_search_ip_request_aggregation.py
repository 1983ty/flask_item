from elasticsearch import Elasticsearch
import urllib,json
def elk_search_ip_request_aggregation(logstash,starttime,endtime): 
    es=Elasticsearch(['172.19.146.77:9200'])
    logstash='logstash-nginx-access-2018*'
    #starttime=starttime+'000'
    #endtime=endtime+'000'
    body={
      "query":{
      "terms":{"clientip":['114.55.15.7','222.249.170.73']}
      },
       "size":0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }

}

##############

    iii = {
    "query":{
        "terms":{
            "clientip.keyword":['222.249.170.73']
        }
    },
        "aggs": {
        "per_count": {
            "terms": {
                "field": "request.keyword"

            }
        }
    }

}
    body = {
        "query":{
        "bool":{
            "must":[
                {
                    "wildcard":{
                        "clientip.keyword":'*'
                    }
                },
                {
                    "wildcard":{
                        "request.keyword":"*index.php?m=goods&c=search&a=search&keyword=*"
                    }
                }
            ]
        },
        "range":{
            "@timestamp":{
                "gte":starttime,
                "lte":endtime       # >=18
                        # <=30
            }
        }

    },
            "aggs": {
        "search_keyword": {
            "terms": {
                "field": "request.keyword",
                 "size":30

            }
        }
       }
    }



    
    
    res=es.search(index=logstash,doc_type="nginx_access",body=body)
    alist=[]
    for k in res['aggregations']['search_keyword']['buckets']:
        name=str(k["key"].split('&keyword=')[1])
        urldecodedCmsBody = urllib.unquote(name)
        count=k['doc_count']
    #    adict[urldecodedCmsBody]=count
        #print urldecodedCmsBody,count
    #res=json.dumps(adict,encoding="UTF-8", ensure_ascii=False)
        alist.append([urldecodedCmsBody,count])
        #print urldecodedCmsBody,count

    #return res['aggregations']['search_keyword']['buckets']
    return alist
if __name__=='__main__':
    logstash='logstash-nginx-access-2018.*'
    ip='60.176.148.177'
    starttime=1525795198000
    endtime=1525831361691

    print elk_search_ip_request_aggregation(logstash,starttime,endtime)    
