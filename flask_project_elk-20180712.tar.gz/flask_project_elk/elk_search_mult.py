from elasticsearch import Elasticsearch
es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
body = {
    "query":{
        "bool":{
            "must":[
                {
                    "term":{
                        "clientip":"47.93.150.169"
                    }
                },
                {
                   "match":{
                          "agent":"gy-top-java"
                         }
                },
                {
                   "match":{
                         "request":"/api/shopexapi/"
                         }
                   
                },
                {
                  "term":{
                         "response":200
                        }
                }   
            ]
        }
    }
}
############################################
body = {
    "query":{
        "bool":{
            "must":[
                {
                    "term":{
                        "clientip":"47.93.150.169"
                    }
                },
                {
                  "term":{
                         "response":200
                        }
                }
            ]
        }
    },
    "aggs":{
    "search_keyword":{
        "terms":{
              "field": "response",
              "size":10

               }
         }
      }

}


res=es.search(index='logstash-nginx-access-2018.06.22',doc_type="nginx_access",body=body)
print res

