from elasticsearch import Elasticsearch
import urllib,json
import urllib,sys,re,os
reload(sys)
sys.setdefaultencoding('utf-8')
t=os.path.dirname(os.path.abspath('.'))
sys.path.append(t)
from db import mysqlconn
from db import mysqlconn_online

def elk_order(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
    body = {
        "query":{
            "wildcard":{
            "request.keyword":"*order/order/detail/order_sn/*"
          }
        },
        "aggs":{
        "search_order_sn":{
            "terms":{
              "field": "request.keyword",
              "size":2000

               }
         }
         }
    }

    alist=[]
    res=es.search(index=logstash,doc_type="nginx_access",body=body,size=20)
    for line in   res['aggregations']['search_order_sn']['buckets']:
        order_sn=line['key']
        order_sn=order_sn.split("/")[-1].split(".html")[0]
        count=line['doc_count']
        result=re.findall(r'\d+',order_sn)
        if len(result)==0:
            continue
        alist.append([order_sn,count])
    return alist

if __name__=='__main__':
    logstash='logstash-nginx-access-2018.06.13'
    result=elk_order(logstash)
    print result
    print len(result)
