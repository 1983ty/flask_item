from elasticsearch import Elasticsearch
es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
#body={
#    "aggregations": {
#        "user": {
#            "terms": {
#                "field": "response",
#                "size": 10,
#                "order": {
#                    "_count": "desc"
#                }
#            }
#        }
#    }
#}
ccc={
  "query": {
    "match_all": {}
  },
  "aggregations": {
    "avg_grade": {
      "avg": {
        "field": "bytes"
      }
    }
  },
  "aggregations": {
    "min_grade": {
      "min": {
        "field": "bytes"
      }
    }
  },
  "aggregations": {
    "max_grade": {
      "max": {
        "field": "bytes"
      }
    }
  }


}
#body={
     
#    "query":{"terms":{"bytes":['118515']}}

#    }
ccc={
      "aggs": {
             "colors": {
         "terms": {
            "field": "agent.keyword",
            "size": 10,
            "order":{"_count":"desc"}
         }
        }
      }
}
ccc={
  "query": {
    "match_all": {}
  },
  "aggregations": {
    "max_grade": {
      "max": {
        "field": "bytes"
       }
      }
      }

    }
body={
    "aggs" : {
        "grades_stats" : { "stats" : { "field" : "bytes" } }
    }
}
aaa={
    "aggs" : {
        "grades_count" : { "value_count" : { "field" : "clientip.keyword" } } 
    }
}
bbb={
    "query": {
        "match": {
            "clientip": "222.249.170.73" 
        }
    },
    "size": 0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }
}
eee={
  "aggs": {
    "uniq_attr": {
      "cardinality": {
        "field": "clientip.keyword"
      }
    }
  }
}
fff={
    "query": {
        "match_all": {
            
        }
    },
    "size": 0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }
}
ggg={'facets':
    {'tag':
        {'terms':
            {'fields':['verb.keyword','client_ip.keyword'],
              'size':10
           }
        }
    },
    'query':
        {'match_all':{}},
    'size':0
}
hhh={
  "query": {
    "multi_match": {
      "fields":  [ "verb", "response" ],
      
      
    }
  }
}
body={
      "query":{
      "terms":{"clientip":['114.55.15.7','222.249.170.73']}
      },
       "size":0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }

}

##############

iii = {
    "query":{
        "terms":{
            "clientip.keyword":['114.55.15.7','222.249.170.73']
        }
    },
        "aggs": {
        "per_count": {
            "terms": {
                "field": "request.keyword"

            }
        }
    }

}

jjj={ 
      "query":{"match_all":{}}
}
body = {
    "query":{
        "range":{
            "response":{
                "gte":400,       # >=18
                "lte":504        # <=30
            }
        }
    }
}


res=es.search(index='logstash-nginx-access-2018.04.25',doc_type="nginx_access",body=body)
#res=es.count(index='logstash-nginx-access-2018.05.04',doc_type="nginx_access",body=jjj)
print res

