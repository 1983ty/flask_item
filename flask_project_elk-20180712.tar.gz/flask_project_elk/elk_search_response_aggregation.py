from elasticsearch import Elasticsearch
es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
body={
    "aggregations": {
        "user": {
            "terms": {
                "field": "response",
                "size": 10,
                "order": {
                    "_count": "desc"
                }
            }
        }
    }
}

res=es.search(index='logstash-nginx-access-2018.04.25',doc_type="nginx_access",body=body,size=300)
for line in  res['aggregations']['user']['buckets']:
    print line

