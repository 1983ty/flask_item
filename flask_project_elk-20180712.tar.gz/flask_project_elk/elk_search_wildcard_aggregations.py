from elasticsearch import Elasticsearch
es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
body = {
    "query":{
        "bool":{
            "must":[
                {
                    "wildcard":{
                        "clientip.keyword":"*"
                    }
                },
                {
                   "match":{
                          "agent":"gy-top-java"
                         }
                },
                {
                   "match":{
                         "request":"/api/shopexapi/"
                         }
                   
                },
                {
                  "term":{
                         "response":200
                        }
                }   
            ]
        }
    },
    "aggs":{
    "search_keyword":{
        "terms":{
              "field": "clientip.keyword",
              "size":10

               }
         }
      }

}

body = {
        "query":{
            "wildcard":{
            "request.keyword":"*/goods/index/lists/id/*.html?brand_id=*"
            #"request.keyword":"*order/order/detail/order_sn*"
          }
        },
        "aggs":{
        "search_keyword":{
            "terms":{
              "field": "request.keyword",
              "size":100

               }
         }
         }
    }


res=es.search(index='logstash-nginx-access-2018.06.30',doc_type="nginx_access",body=body)
print res['aggregations']

