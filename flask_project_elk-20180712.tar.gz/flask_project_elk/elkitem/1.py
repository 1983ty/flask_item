from elasticsearch import Elasticsearch
def elkconn():
    es=Elasticsearch(['172.19.147.77:9200'])
    return  es

def getcount():
    es=elkconn()
    rescount=es.count(index='logstash-nginx-access-2018.04.04',doc_type='nginx_access')
    print rescount['count']
    return rescount['count']

getcount()

