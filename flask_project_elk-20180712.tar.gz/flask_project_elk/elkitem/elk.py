# -*- encoding: utf-8 -*-  
import sys  
import json 
import urllib2 
import re
from elasticsearch import Elasticsearch 
reload(sys)
sys.setdefaultencoding("utf8") 
def elkconn():
    es = Elasticsearch(  
        ['172.19.146.77:9200']  
    )  

    return es
def getindexlist():
    urlf=open('es_url.txt','w')
    url='http://localhost:9200/_cat/indices'
    res=urllib2.urlopen(url)
    res=res.read()
    urlf.write(res)
    urlf.close()
def reades_list():
    logstash_index=[]
    #res=re.findall(r'\w+\-nginx\-\w+\-\d+\.\w+\.\w+',t)
    with open('es_url.txt','r') as fobj:
        for line in fobj:
            line=line.strip()
            line=line.split(' ')[2]
            res=re.findall(r'\w+\-nginx\-\w+\-\d+\.\w+\.\w+',line)
            if len(res)==0:
                continue
            logstash_index.append(res[0])
        return logstash_index
def getcount(*args):
    es=elkconn()
    rescount=es.count(index=args[0],doc_type='nginx_access')
    #print rescount['count']
    return rescount['count']
    
def getsearch(*args):
    alist={}
    es=elkconn()
    rescount=getcount(*args)
    body={
    "from" :0 , "size" : 10000
    }
    while True:
        res=es.search(index=args[0],doc_type='nginx_access',sort="@timestamp:desc",body=body)
        for line in res['hits']['hits']:
            try:
                ip=line['_source']['clientip']
                #print line['_index'],"\t",line['_type'],"\t",line['_id'],"\t",line['_source']['clientip'],"\t",line['_source']['request'],"\t",line['_source']['response'],"\t",line['_source']['bytes'],"\t",line['_source']['@timestamp']
            except Exception,e:
                continue
            
            alist[ip]=alist.get(ip,0)+1
        body['from']=body.get('from')+body.get('size')
         
        if body.get('from')>=rescount:
            #print body,rescount,'is larger'
            break
        #print body
    return sorted(alist)

def sorted(alist):
    result=alist.items()
    n=len(result)
    for i in range(1,n):
        for j in range(n-i):
            if result[j][1]<result[j+1][1]:
                result[j],result[j+1]=result[j+1],result[j]
    #for line in result:
       
    #    print line[0],"\t",line[1] 
    return result
def ipsearch():
    es=elkconn()
    body = {
    "query":{
        "wildcard":{
            "clientip":"222.249.170.73"
        }
    }
    }
    res=es.search(index='logstash-2018.04.12',doc_type='nginx_access',size=50000,body=body)
    print res
def getipview():
    es=elkconn()
    print es.get(index='logstash-2018.03.27',id='AWJmdRrmM5_-AE40UBzm',doc_type='nginx_access')


def getindex_count():
    es=elkconn()
    for indexname in reades_list:
        amount=es.count(index=indexname,doc_type='nginx_access')
        print indexname,amount
    

    
        
if __name__=='__main__':
#    getindexlist()
#    reades_list=reades_list()
#    getindex_count()
#    getcount()
#    getsearch()
#    ipsearch()
 #   getipview()
    getcount('logstash-nginx-access-2018.04.17')


