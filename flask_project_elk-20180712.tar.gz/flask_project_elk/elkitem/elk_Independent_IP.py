# -*- encoding: utf-8 -*-
import sys
import json
import urllib2
import re
reload(sys)
from elasticsearch import Elasticsearch
from elk import elkconn 
def total_Independent_IP(*args):
    es=elkconn()
    rescount=es.count(index=args[0],doc_type='nginx_access')
    rescount=rescount['count']
    

    alist={}
    #es=elkconn()
    aaa=[] 
    body={
    "from" :0 , "size" : 10000
    }
    while True:
        res=es.search(index=args[0],doc_type='nginx_access',sort="@timestamp:desc",body=body)
        for line in res['hits']['hits']:
            try:
                ip=line['_source']['clientip']
                #print line['_index'],"\t",line['_type'],"\t",line['_id'],"\t",line['_source']['clientip'],"\t",line['_source']['request'],"\t",line['_source']['response'],"\t",line['_source']['bytes'],"\t",line['_source']['@timestamp']
            except Exception,e:
                continue

            alist[ip]=alist.get(ip,0)+1
        body['from']=body.get('from')+body.get('size')

        if body.get('from')>=rescount:
            #print body,rescount,'is larger'
            break
        #print body
    return  len(alist)








if __name__=='__main__':
    total_Independent_IP('logstash-nginx-access-2018.04.13')


