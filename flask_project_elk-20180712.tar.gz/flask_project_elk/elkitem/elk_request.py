# -*- encoding: utf-8 -*-
import sys
import json
import urllib2
import re
import elk
from elasticsearch import Elasticsearch
reload(sys)
sys.setdefaultencoding("utf8")

def getsearch(logstash):
    
    print logstash
    es=elk.elkconn() 
    rescount=elk.getcount(logstash)
    
    alist={}
    
    body={
    "from" :0 , "size" : 10000
    }
    while True:
        res=es.search(index=logstash,doc_type='nginx_access',sort="@timestamp:desc",body=body)
        for line in res['hits']['hits']:
            try:
                request=line['_source']['request']
                
                #print line['_index'],"\t",line['_type'],"\t",line['_id'],"\t",line['_source']['clientip'],"\t",line['_source']['request'],"\t",line['_source']['response'],"\t",line['_source']['bytes'],"\t",line['_source']['@timestamp']
            except Exception,e:
                continue

            alist[request]=alist.get(request,0)+1
        body['from']=body.get('from')+body.get('size')

        if body.get('from')>=rescount:
            #print body,rescount,'is larger'
            break
        #print body
    result=alist.items()
    n=len(result)
    for i in range(1,n):
        for j in range(n-i):
            if result[j][1]<result[j+1][1]:
                result[j],result[j+1]=result[j+1],result[j]
    result = result[0:5]
    return result
    
    
if __name__=='__main__':
    logstash='logstash-nginx-access-2018.04.08'
    getsearch(logstash)
