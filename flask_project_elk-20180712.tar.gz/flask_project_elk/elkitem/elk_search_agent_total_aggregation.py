from elasticsearch import Elasticsearch
def elk_search_agent_total(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
#body={
#    "aggregations": {
#        "user": {
#            "terms": {
#                "field": "response",
#                "size": 10,
#                "order": {
#                    "_count": "desc"
#                }
#            }
#        }
#    }
#}
#ccc={
#  "query": {
#    "match_all": {}
#  },
#  "aggregations": {
#    "avg_grade": {
#      "avg": {
#        "field": "bytes"
#      }
#    }
#  },
#  "aggregations": {
#    "min_grade": {
#      "min": {
#        "field": "bytes"
#      }
#    }
#  },
#  "aggregations": {
#    "max_grade": {
#      "max": {
#        "field": "bytes"
#      }
#    }
#  }


#}
#body={
     
#    "query":{"terms":{"bytes":['118515']}}

#    }
#ccc={ 
#   "aggs": { 
#      "colors": { 
#         "terms": { 
#            "field": "bytes" 
#         }, 
#         "aggs": { 
#            "avg_price": { "avg": { "field": "bytes" } 
#            }, 
#            "make" : { 
#                "terms" : { 
#                    "field" : "bytes" 
#                }, 
#                "aggs" : { 
#                    "min_price" : { "min": { "field": "bytes"} }, 
#                    "max_price" : { "max": { "field": "bytes"} } 
#                } 
#            } 
#         } 
#      } 
#   } 
#} 
    body={
      "aggs": {
             "total": {
         "terms": {
            "field": "agent.keyword",
            "size": 10,
            "order":{"_count":"desc"}
         }
        }
      }
    }


    res=es.search(index=logstash,doc_type="nginx_access",body=body)
    return res['aggregations']['total']['buckets']
if __name__=='__main__':
    logstash='logstash-nginx-access-2018.05.05'
    print elk_search_agent_total(logstash)
