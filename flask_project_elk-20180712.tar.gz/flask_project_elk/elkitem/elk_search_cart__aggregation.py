from elasticsearch import Elasticsearch
import urllib,json
def elk_keyword(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
    body = {
        "query":{
            "wildcard":{
            "request.keyword":"*order/order/detail/order_sn/*"
          }
        },
        "aggs":{
        "search_order_sn":{
            "terms":{
              "field": "request.keyword",
              "size":20

               }
         }
         }
    }
    adict={}
    res=es.search(index=logstash,doc_type="nginx_access",body=body,size=20)
    for line in   res['aggregations']['search_order_sn']['buckets']:
        order_sn=line['key']
        order_sn=order_sn.split("/")[-1].split(".html")[0]
        count=line['doc_count']
        print order_sn,count
            
                
            
                
               




if __name__=='__main__':
    logstash='logstash-nginx-access-2018.0*.*'
    elk_keyword(logstash)
