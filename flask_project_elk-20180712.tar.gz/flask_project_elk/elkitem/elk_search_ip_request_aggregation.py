from elasticsearch import Elasticsearch
def elk_search_ip_request_aggregation(logstash,ip): 
    es=Elasticsearch(['172.19.146.77:9200'])
    body={
      "query":{
      "terms":{"clientip":['114.55.15.7','222.249.170.73']}
      },
       "size":0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
    }

}

##############

    iii = {
    "query":{
        "terms":{
            "clientip.keyword":['222.249.170.73']
        }
    },
        "aggs": {
        "per_count": {
            "terms": {
                "field": "request.keyword"

            }
        }
    }

}
    body = {
        "query":{
        "bool":{
            "must":[
                {
                    "term":{
                        "clientip.keyword":ip
                    }
                },
                {
                    "terms":{
                        "response":[200,301,302,304,499,400,404,408,405]
                    }
                }
            ]
        }
    },
            "aggs": {
        "per_count": {
            "terms": {
                "field": "request.keyword",
                 "size":30

            }
        }
       }
    }



    res=es.search(index=logstash,doc_type="nginx_access",body=body)
    print res

    return res['aggregations']['per_count']['buckets']
if __name__=='__main__':
    logstash='logstash-nginx-access-2018.05.15'
    ip='60.176.148.177'
    print elk_search_ip_request_aggregation(logstash,ip)    
