from elasticsearch import Elasticsearch


def get_ip_serch(logstash):
    es=Elasticsearch(["172.19.146.77:9200"])

