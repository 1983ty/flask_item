from elasticsearch import Elasticsearch
def get_ip_unique(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
    body={
    "aggs": {
    "uniq_attr": {
      "cardinality": {
        "field": "clientip.keyword"
          }
        }
      }
    }


    res=es.search(index=logstash,doc_type="nginx_access",body=body)
    return str(res['aggregations']['uniq_attr']['value'])
if __name__=='__main__':
    logstash='logstash-nginx-access-2018.04.27'
    print type(get_ip_unique(logstash))
