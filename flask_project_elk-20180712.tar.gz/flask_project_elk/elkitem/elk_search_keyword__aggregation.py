from elasticsearch import Elasticsearch
import urllib,json
def elk_keyword(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
    body = {
        "query":{
            "wildcard":{
            "request.keyword":"*index.php?m=goods&c=search&a=search&keyword=*"
            #"request.keyword":"*order/order/detail/order_sn*"
          }
        },
        "aggs":{
        "search_keyword":{
            "terms":{
              "field": "request.keyword",
              "size":2000

               }
         }
         }
    }
    adict={}
    res=es.search(index=logstash,doc_type="nginx_access",body=body)
    for k in res['aggregations']['search_keyword']['buckets']:
        name=str(k["key"].split('&keyword=')[1])
        urldecodedCmsBody = urllib.unquote(name)
        count=k['doc_count']
    #    adict[urldecodedCmsBody]=count
        #print urldecodedCmsBody,count    
    #res=json.dumps(adict,encoding="UTF-8", ensure_ascii=False)  
    #print adict
        print urldecodedCmsBody,count        
            
                
            
                
               




if __name__=='__main__':
    logstash='logstash-nginx-access-2018.05.12'
    elk_keyword(logstash)
