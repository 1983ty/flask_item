from elasticsearch import Elasticsearch
import urllib,sys
reload(sys)
sys.setdefaultencoding('utf-8')
from db import mysqlconn



def get_detail(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
   

    body = {
    "query":{
        "wildcard":{
            "request.keyword":"*goods/index/lists/id/*.html"
           # "request.keyword":"*goods/index/lists/id/*.html?brand_id=*"
        }
    },
    "aggs":{
    "search_keyword":{
        "terms":{
              "field": "request.keyword",
              "size":50

               }
         }
      }
    }
    res=es.search(index=logstash,doc_type="nginx_access",body=body)
    print res
    return res['aggregations']['search_keyword']['buckets']
if __name__=='__main__':
    logstash='logstash-nginx-access-2018.06.*'
    print get_detail(logstash)
