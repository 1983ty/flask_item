from elasticsearch import Elasticsearch
def get_range_time_count(starttime,endtime):
    es=Elasticsearch(['172.19.146.77:9200'])
    logstash='logstash-nginx-access-2018*'
    starttime=starttime+'000'
    endtime=endtime+'000'

    body = {
    "query":{
        "range":{
            "@timestamp":{
                "gte":starttime,
                "lte":endtime       # >=18
                        # <=30
            }
        }

    }

    }

    res=es.count(index=logstash,doc_type="nginx_access",body=body)
    return str(res['count'])











if __name__=='__main__':
    logstash='logstash-nginx-access-2018*'
    starttime=1525795198000 
    endtime=1525831361691
    print get_range_time_count(starttime,endtime)
