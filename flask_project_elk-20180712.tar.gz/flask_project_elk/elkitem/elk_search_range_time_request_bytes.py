from elasticsearch import Elasticsearch
def elk_search_range_time_request_bytes(starttime,endtime):
    es=Elasticsearch(['172.19.146.77:9200'])
    logstash='logstash-nginx-access-2018*'
    starttime=starttime+'000'
    endtime=endtime+'000'

    body = {
    "query":{
        "range":{
            "@timestamp":{
                "gte":starttime,
                "lte":endtime       # >=18
                        # <=30
            }
        }
    },
    "aggs":{                 
         "total": {
         "terms": {
            "field": "request.keyword",
            "size": 10,
            "order":{"_count":"desc"}
         }
        }
       
            
        
    }
}
    jjj={
      "query":{
        "range":{
            "@timestamp":{
                "gte":starttime,
                "lte":endtime       # >=18
                        # <=30
            }
        }
    },
  "aggs": {
    "missing_address": {
      "terms": {
        "field": "request.keyword"
      },
      "aggs": {                
        "max_age": {
          "max": {              
             "field" : "bytes"
          }
        }
      }
    }
  }
}
    hhh={
      "query":{
        "range":{
            "@timestamp":{
                "gte":starttime,
                "lte":endtime       # >=18
                        # <=30
            }
        }
    },
  "aggs": {
    "request_bytes": {
      "terms": {
        "field": "request.keyword"
      },
      "aggs": {
          
            "grades_stats" : { "stats" : { "field" : "bytes" } }
          
      }
    }
  }
}


    res=es.search(index=logstash,doc_type="nginx_access",body=hhh)
    #return res['aggregations']['total']['buckets']
    return res['aggregations']['request_bytes']['buckets']











if __name__=='__main__':
    logstash='logstash-nginx-access-2018*'
    starttime=1525795198000 
    endtime=1525831361691
    print elk_search_range_time_request_bytes(starttime,endtime)
