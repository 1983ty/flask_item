from elasticsearch import Elasticsearch
def elk_search_request_bytes(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
    #starttime=starttime+'000'
    #endtime=endtime+'000'

    body={
      "query":{
             "match_all":{} 
        
    },
  "aggs": {
    "request_bytes": {
      "terms": {
        "field": "request.keyword",
        "size":20
      },
      "aggs": {
          
            "grades_stats" : { "stats" : { "field" : "bytes" } }
          
      }
    }
  }
}


    res=es.search(index=logstash,doc_type="nginx_access",body=body)
    #return res['aggregations']['total']['buckets']
    return res['aggregations']['request_bytes']['buckets']











if __name__=='__main__':
    logstash='logstash-nginx-access-2018*'
    starttime=1525795198000 
    endtime=1525831361691
    print elk_search_request_bytes(logstash)
