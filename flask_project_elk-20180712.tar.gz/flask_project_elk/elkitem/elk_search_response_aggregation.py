from elasticsearch import Elasticsearch
def elk_search_response(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
#body={
#      "query":{
#      "terms":{"clientip":['114.55.15.7','114.55.15.10']}
#      }
#}
#/api/shopexapi/
#body={
#      "query":{
#      "match":{"agent":"gy-top-java"}
#      }
#}
#body={
#         "query":{"match_all":{}}
#}
    body={
        "aggregations": {
        "user": {
            "terms": {
                "field": "response",
                "size": 10,
                "order": {
                    "_count": "desc"
                }
            }
        }
    }
    }

    res=es.search(index=logstash,doc_type="nginx_access",body=body,size=300)

    return  res['aggregations']['user']['buckets']

if __name__=='__main__':
    logstash='logstash-nginx-access-2018.04.25'
    print elk_search_response(logstash)
