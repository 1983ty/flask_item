from elasticsearch import Elasticsearch
def getverb_search(logstash):
    es=Elasticsearch(['172.19.146.77:9200'])
        
    fff={
        "query": {
        "match_all": {
            
        }
    },
    "size": 0,
    "aggs": {
        "per_count": {
            "terms": {
                "field": "verb.keyword"
            }
        }
      }
    }

    res=es.search(index=logstash,doc_type="nginx_access",body=fff)
    return res['aggregations']['per_count']['buckets']
if __name__=='__main__':
    logstash='logstash-nginx-access-2018.03.26'
    print getverb_search(logstash)


