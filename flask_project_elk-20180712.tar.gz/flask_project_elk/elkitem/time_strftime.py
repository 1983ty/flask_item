import time
from db import mysqlconn
class get_transfer(object):

    def transfer_time(self):
        Fri_list=[]
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        #c=time.strptime(a,'%Y.%m.%d')
        #stime=time.strftime("%a",c)
        #if stime=='Fri':
        #    print a,stime
        for line  in rows:
            
            a=line[0].replace('logstash-nginx-access-','')
            c=time.strptime(a,'%Y.%m.%d')
            stime=time.strftime("%a",c)
            if stime=='Fri':
                Fri_list.append(a)
        return Fri_list




if __name__=='__main__':
    a='2018.06.08'
    p=get_transfer()
    print p.transfer_time()

