from  sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column,Integer,String
from sqlalchemy.orm import sessionmaker
engine=create_engine("mysql+mysqldb://photo:12345678@172.19.146.77:3306/malllogs",encoding='utf-8',echo=True)

Base=declarative_base()
class User(Base):
    __tablename__='user'
    id = Column(Integer,primary_key=True)
    name=Column(String(32))
    password=Column(String(64))
    def __repr__(self):
        #return "<%s name:%s,password:%s>" % (self.id,self.name,self.password)
        return self.password

#Base.metadata.create_all(engine)
Session_class=sessionmaker(bind=engine)
Session=Session_class()
#data=Session.query(User).filter_by(name="alex").all()
#data=Session.query(User).filter(User.id>1).count()
#data=Session.query(User).filter(User.id>1).all()
data=Session.query(User).filter(User.name=="admin").all()
#data=Session.query(User).filter(User.id>1).filter(User.id<4).all()
print data


