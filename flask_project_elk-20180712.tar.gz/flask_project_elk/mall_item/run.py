#!/usr/bin/python
#!- coding: utf-8 -
import sys
import os,time
reload(sys)
sys.setdefaultencoding("utf-8")
from flask import Flask,render_template
from flask import request
from flask import redirect,session
from db import sqlalchemy_select
from db import mysqlconn
from db import mysqlconn_online
from timestring import get_strftime
from timestring import change_overtime
import hashlib,re
app=Flask(__name__)
app.config["SECRET_KEY"] = "test"
app.secret_key='bvfdsbfjsgbse'
from  sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column,Integer,String
from sqlalchemy.orm import sessionmaker
engine=create_engine("mysql+mysqldb://photo:12345678@172.19.146.77:3306/malllogs",encoding='utf-8',echo=True)

Base=declarative_base() #实例化一个变量
class User(Base):
    __tablename__='user'
    id = Column(Integer,primary_key=True)
    name=Column(String(32))
    password=Column(String(64))
    def __repr__(self):
        #return "<%s name:%s,password:%s>" % (self.id,self.name,self.password)
        return self.password

#Base.metadata.create_all(engine)
Session_class=sessionmaker(bind=engine) #启动连接数据库
Session=Session_class() #调取session加载
#data=Session.query(User).filter_by(name="alex").all()
#data=Session.query(User).filter(User.id>1).count()
#data=Session.query(User).filter(User.id>1).all()
#data=Session.query(User).filter(User.name=="admin").all()
#data=Session.query(User).filter(User.id>1).filter(User.id<4).all()
#print data

@app.route('/admin')
#app调取admin接口
def index():
    #data=Session.query(User).filter(User.name=="admin").all()
    #print data
    return render_template('mall_login.html') #模版文件跳转到登录页
@app.route('/login_check',methods=['GET', 'POST']) #通过模版的mall_login.html文件提交post登录请求验证登录
def login_check():
    uname=request.values.get("username") #获取输入的用户名
    pwd=request.values.get("pwd").strip()#获取输入的密码
    pwd_r=hashlib.md5(pwd).hexdigest()#将密码md5加密，下一步和数据库的密码字段比对。
    data=Session.query(User).filter(User.name==uname).all() #调取sqlalchemy读取数据库查询返回结果

    result=str(data[0]) #将结果给result变量，并且返回的data是class类型所以要用str（）函数转换成字符串
    print result
    if result==pwd_r: #比较数据库的password字段密码和用户输入密码的md5加密的是否一致
    
        session['logined'] =True #写入session
        print session
        return render_template('admin.html') #符合条件返回页面
    else: #不符合返回错误页面并且输出msg错误信息模版内容
        return render_template('mall_login.html',msg="Wrong, name is %s or password again!" % uname)

@app.route('/logout')
def logout():
    if 'logined' in session:
        session.pop('logined')
        return '<h1>logout succeed</h1>'
    return '<h1>logout failed<h1>'
@app.route('/test_login')
def test_login(): #测试是否登录成功
    if 'logined' in session:
        return '<h1>you are still in</h1>' #返回消息
    else:
        return '<h1>you have logouted</h1>' #返回没登录信

@app.route('/mall_total',methods=['GET','POST'])
def mall_total():
    if 'logined' in session:
        t='%'
        location=change_overtime.change_overtime()
        #sql="select (select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as a,(select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as b,(select sum(real_amount) from `order_sub` where order_sn like '%s' and pay_status=1) as c  from `order_sub` limit 1" %(location[0:4]+t,location[0:6]+t,location+t)
        sql="select (select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as a,(select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as b,(select sum(real_amount) from `order_sub` where order_sn like '%s' and pay_status=1) as c, (select  count(*) from  order_refund as a join `order` as b on b.sn=a.order_sn where pay_status=1 and a.status=0 and type=2) as d,(select count(*) from order_sub where delivery_status=0 and  pay_status=1 and confirm_status=2 and status=1) as e,(select count(*) from  order_sub as a join `order` as b on a.order_sn=b.sn  where a.confirm_status=0 and a.pay_status=1) as f,(select count(*) from  order_refund where type=1 and status=0) as g,(select count(*) from  goods_sku where   status=1) as h,(select count(*) from  goods_sku where   status=0) as i,(select count(*) from  goods_sku where  number<=warn_number and status=1) as j,(select count(*) from order_sub where finish_status=2) as k,(select count(*)  from member) as l,(select count(*) from `order` where status=1 and confirm_status=0 and finish_status=0) as m  from order_sub limit 1" %(location[0:4]+t,location[0:6]+t,location+t)
        rows=mysqlconn_online.mysqlconn(sql)
        
        if len(rows)>=1:
            print rows[0]
            
            years=str(rows[0][0])
            mouth=str(rows[0][1])
            today=str(rows[0][2])
            order_refund=str(rows[0][3])
            order_wait=str(rows[0][4])
            order_confirm=str(rows[0][5])
            order_refund_shenqing=str(rows[0][6])
            goods_sku_online=str(rows[0][7])
            goods_sku_waite=str(rows[0][8])
            goods_sku_reduce=str(rows[0][9])
            order_finish=str(rows[0][10])
            member=str(rows[0][11])
            unfinish_order=str(rows[0][12])
            print order_confirm,order_refund,order_wait,order_refund_shenqing,'-------------------------------%s,%s,%s' % (years,mouth,today)
            return render_template('index.html',years=years,mouth=mouth,today=today,order_refund=order_refund,order_wait=order_wait,order_confirm=order_confirm,order_refund_shenqing=order_refund_shenqing,goods_sku_online=goods_sku_online,goods_sku_waite=goods_sku_waite,goods_sku_reduce=goods_sku_reduce,order_finish=order_finish,member=member,unfinish_order=unfinish_order)            













if __name__=='__main__':
    app.run(host='0.0.0.0',debug=True)


