#!/usr/bin/python
#!- coding: utf-8 -
import sys
import os,time
reload(sys)
sys.setdefaultencoding("utf-8")
from flask import Flask,render_template
from flask import request
from flask import redirect,session
from db import mysqlconn
from db import mysqlconn_online
from timestring import get_strftime
from elkitem import elk
from elkitem import elk_Independent_IP
from elkitem import elk_request
from elkitem import elk_search_ip_unique_aggregation
from elkitem import elk_search_response_aggregation
from elkitem import elk_search_ip_total_aggregation
from elkitem import elk_search_resquest_total_aggregation
from elkitem import elk_search_agent_total_aggregation
from elkitem import elk_search_verb_total_aggregation
from elkitem import elk_search_range_time_count_aggregation
from elkitem import elk_search_keyword__aggregation
from elkitem import elk_search_order_aggregation
from elkitem import elk_search_range_time_ip_unique
from elkitem import elk_search_range_time_ip
from elkitem import elk_search_range_time_response
from elkitem import elk_search_range_time_agent
from elkitem import elk_search_range_time_verb
from elkitem import elk_search_ip_request_aggregation
from elkitem import elk_search_request_bytes
from elkitem import elk_search_range_time_request_bytes
from elkitem import elk_search_detail
from elkitem import elk_search_order_mouth_aggregation
from csv_opration import csv_output
from elkitem.time_strftime import get_transfer
from elkitem import elk_search_list_detail
from timestring import change_overtime
p=get_transfer()
print p.transfer_time()
import hashlib,re
app=Flask(__name__)
app.config["SECRET_KEY"] = "test"
app.secret_key='bvfdsbfjsgbse'
@app.route('/')
@app.route('/login')
def index():

    return render_template('login.html')
@app.route('/login_check',methods=['GET', 'POST'])
def login_check():
    name=request.values.get("uname")
    pwd=request.values.get("pwd").strip()
    pwd_r=hashlib.md5(pwd).hexdigest()
    sql="select name,password from user where name='%s' and password='%s' " %(name,pwd_r)
    print sql
    rows=mysqlconn.mysqlconn(sql)
    if len(rows)==1:
        session["logined"] =True

        #return render_template('loginok.html')
        return render_template('main.html',name=name)
    else:
        return render_template('login.html',msg="Wrong, name is %s ry again!" % name)
@app.route('/logout')
def logout():
    if 'logined' in session:
        session.pop('logined')
        return '<h1>logout succeed</h1>'
    return '<h1>logout failed<h1>'
@app.route('/test_login')
def test_login():
    if 'logined' in session:
        return '<h1>you are still in</h1>'
    else:
        return '<h1>you have logouted</h1>'
@app.route('/search_elk_total')
def search_elk_total():
    
    if session["logined"] ==True:
        sql="select logstash,amount from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('main_elk_count.html',rows=rows)
    else:
        return render_template('login.html')
@app.route('/logstash_statics',methods=['GET', 'POST'])
def logstash_statics():
    if session["logined"] ==True:
        logstash=request.values.get("logstash")
    
        print '==============================================================',logstash
        #result=elk.getsearch(logstash)
        result=elk_search_ip_total_aggregation.elk_search_ip_total(logstash)
    
        #return render_template('logstash_each_total.html',rows=result[0:5])
        return render_template('logstash_each_total.html',rows=result,logstash=logstash)
@app.route('/total_ip',methods=['GET', 'POST'])
def total_ip():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('main_elk_list.html',rows=rows)
    else:
        return render_template('login.html')    
@app.route('/elk_Independent_IP',methods=['GET','POST']) 
def total_elk_Independent_IP():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        #result=elk_Independent_IP.total_Independent_IP(logstash)
        result=elk_search_ip_unique_aggregation.get_ip_unique(logstash)
        #result=elk_search_ip_total_aggregation.elk_search_ip_total(logstash)
        if result:
            result=str(result)
            return render_template('view_elk_Independent_IP.html',logstash=logstash,rows=result)
        else:
            return 'not logstash total'
@app.route('/get_url_total',methods=['GET','POST']) 
def get_url_total_list():
           
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('main_url_total_list.html',rows=rows)
    else:
        return render_template('login.html')
@app.route('/view_get_url_total',methods=['GET','POST'])
def view_get_url_total():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        #result=elk_request.getsearch(logstash)
        result=elk_search_resquest_total_aggregation.elk_search_request_total(logstash)
        print result
        return render_template('view_get_url_total.html',rows=result)
@app.route('/get_response',methods=['GET','POST'])
def get_response_list():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('get_response_list.html',rows=rows)
    else:
        return render_template('login.html')

@app.route('/get_response_result',methods=['GET','POST'])
def get_response_result():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        res=elk_search_response_aggregation.elk_search_response(logstash)
        return render_template('get_response_result.html',rows=res)
@app.route('/get_agent_list',methods=['GET','POST'])
def get_agent_list():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('get_agent_list.html',rows=rows)
    else:
        return render_template('login.html')
@app.route('/get_agent_result',methods=['GET','POST'])
def get_agent_result():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        res=elk_search_agent_total_aggregation.elk_search_agent_total(logstash)
        return render_template('get_agent_result.html',rows=res)
@app.route('/get_verb_list')
def get_verb_list():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('get_verb_list.html',rows=rows)
    else:
        return render_template('login.html')

@app.route('/get_verb_result',methods=['GET','POST'])
def get_verb_result():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        res=elk_search_verb_total_aggregation.getverb_search(logstash)
        return render_template('get_agent_result.html',rows=res)

@app.route('/get_time')
def get_time():
    if session["logined"] ==True:
        return render_template('get_time.html')
    
@app.route('/get_range_result',methods=['GET','POST'])
def get_range_result():
    if session["logined"] ==True:
        starttime=str(request.values.get("starttime")).strip()
        endtime=str(request.values.get("endtime")).strip()
      
        if len(str(starttime)) ==14 and len(str(endtime))==14:
            starttime=str(get_strftime.gettime(starttime)).split('.')[0]
            endtime=str(get_strftime.gettime(endtime)).split('.')[0]
            result=elk_search_range_time_count_aggregation.get_range_time_count(starttime,endtime)
            ip_unique=elk_search_range_time_ip_unique.get_range_time_ip_unique(starttime,endtime)
            ip_rows=elk_search_range_time_ip.get_range_time_ip(starttime,endtime)
            response_rows=elk_search_range_time_response.get_range_time_response(starttime,endtime)
            agent_rows=elk_search_range_time_agent.elk_search_range_time_agent(starttime,endtime)
            verb_rows=elk_search_range_time_verb.elk_search_range_time_verb(starttime,endtime)
            rows=elk_search_range_time_request_bytes.elk_search_range_time_request_bytes(starttime,endtime)
            #return '%s %s' %(starttime,endtime)
            return render_template('get_range_result.html',starttime=starttime,endtime=endtime,result=result,ip_unique=ip_unique,ip_rows=ip_rows,response_rows=response_rows,verb_rows=verb_rows,agent_rows=agent_rows,rows=rows)
        else:
            return 'no endtime and starttime'
@app.route('/get_keyword_list')
def get_keyword_list():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('get_keyword_list.html',rows=rows)
    else:
        return render_template('login.html')
@app.route('/get_keyword_result',methods=['GET','POST'])
def get_keyword_result():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        sql="select id as ids from logstash_list where logstash='%s' " % logstash
        rows=mysqlconn.mysqlconn(sql)
        if rows:
            ids=rows[0]
            print '-------------------------------',ids
            sql="select keyword,amount from logstash_keyword where logstash_id='%s'" % ids
            rows=mysqlconn.mysqlconn(sql)
            return render_template('get_keyword_result.html',rows=rows)
        
    else:
        return render_template('login.html')
#@app.route('/get_keyword_all',methods=['GET','POST'])
#def get_keyword_all():
#    if session["logined"] ==True:
#        sql="select count(distinct(keyword)) from logstash_keyword"
#        number_total=mysqlconn.mysqlconn(sql)
#        number_total=str(number_total)
#        sql="select keyword,sum(amount)as mmm from logstash_keyword group by keyword order by  mmm desc limit 0,50"
#        rows=mysqlconn.mysqlconn(sql)
#        return render_template("get_keyword_all.html",rows=rows)

@app.route('/get_order_list')
def get_order_list():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('get_order_list.html',rows=rows)
    else:
        return render_template('login.html')
@app.route('/get_order_result',methods=['GET','POST'])
def get_order_result():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        rows=elk_search_order_aggregation.elk_order(logstash)
        num=str(len(rows))
        print '------------------------------',num
        return render_template('get_order_result.html',rows=rows,num=num)
        
@app.route('/get_order_name',methods=['GET','POST'])
def get_order_name():
    if session["logined"] ==True:
        order_sn=request.values.get("order_sn").strip()
        sql="select order_sn,sub_sn,sku_name,real_price from order_sku where order_sn='%s'" % order_sn
        rows=mysqlconn_online.mysqlconn(sql)
        print rows
        order_sn=rows[0][0]
        sub_sn=rows[0][1]
        sku_name=rows[0][2]
        real_price=rows[0][3]
        #return '%s,%s,%s,%s' %(order_sn,sub_sn,sku_name,real_price)
        return render_template('get_order_name.html',order_sn=order_sn,sub_sn=sub_sn,sku_name=sku_name,real_price=real_price)

@app.route('/get_ip_request',methods=['GET','POST'])
def get_ip_request():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        ip=request.values.get("ip").strip()
        print '---------------------',ip
        rows=elk_search_ip_request_aggregation.elk_search_ip_request_aggregation(logstash,ip)
        return render_template('view_get_url_total.html',rows=rows)

##############################################

@app.route('/get_keyword_all',methods=['GET','POST'])
def get_keyword_all():
    if session["logined"] ==True:
        page=0
        sql="select count(distinct(keyword)) from logstash_keyword"
        number_total=mysqlconn.mysqlconn(sql)
        number_total=number_total[0][0]
        limittotal=number_total/50
        print limittotal 
        sql="select keyword,sum(amount)as mmm from logstash_keyword group by keyword order by  mmm desc limit 0,50"
        rows=mysqlconn.mysqlconn(sql)
        return render_template("get_keyword_all.html",rows=rows,number_total=number_total,limittotal=limittotal,page=page)
@app.route("/get_keyword_limit",methods=['GET','POST'])
def get_keyword_limit():
    if session["logined"] ==True:
        
        page=request.values.get("page").strip()
        num=int(page)*50
        print num
        sql="select count(distinct(keyword)) from logstash_keyword"
        number_total=mysqlconn.mysqlconn(sql)
        number_total=number_total[0][0]
        limittotal=number_total/50
        sql="select keyword,sum(amount)as mmm from logstash_keyword group by keyword order by  mmm desc limit %s,50" % num        
        rows=mysqlconn.mysqlconn(sql)
        return render_template("get_keyword_limit.html",rows=rows,number_total=number_total,limittotal=limittotal,page=page)


@app.route("/get_keyword_limitup",methods=['GET','POST'])
def get_keyword_limitup():
    if session["logined"] ==True:

        page=request.values.get("page").strip()
        page=int(page)
        num=int(page)*50
        print num
        sql="select count(distinct(keyword)) from logstash_keyword"
        number_total=mysqlconn.mysqlconn(sql)
        number_total=number_total[0][0]
        limittotal=number_total/50
        sql="select keyword,sum(amount)as mmm from logstash_keyword group by keyword order by  mmm desc limit %s,50" % num
        rows=mysqlconn.mysqlconn(sql)
        return render_template("get_keyword_limit_up.html",rows=rows,number_total=number_total,limittotal=limittotal,page=page)

@app.route("/get_url_bytes_list",methods=['GET','POST'])
def get_url_bytes_list():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('get_request_bytes_list.html',rows=rows)
    else:
        return render_template('login.html')

@app.route("/get_request_bytes_result",methods=['GET','POST'])
def get_request_bytes_result():
    if session["logined"] ==True:
        logstash=request.values.get("logstash").strip()
        rows=elk_search_request_bytes.elk_search_request_bytes(logstash)
        return render_template("get_request_bytes_result.html",rows=rows) 
#################################################
@app.route("/down_keyword",methods=['GET','POST'])
def down_keyword():
    if session["logined"] ==True:
        page=request.values.get("page").strip()
        page=int(page)
        page=int(page)*50
        sql="select keyword,sum(amount)as mmm from logstash_keyword group by keyword order by  mmm desc limit %s,50" % page
        rows=mysqlconn.mysqlconn(sql)
        result=csv_output.csv_output(rows)
        return redirect('static/download/example.csv')
@app.route("/down_keyword_all",methods=['GET','POST'])
def down_keyword_all():
    if session["logined"] ==True:
        #page=request.values.get("page").strip()
        #page=int(page)
        #page=int(page)*50
        sql="select keyword,sum(amount)as mmm from logstash_keyword group by keyword order by  mmm desc"
        rows=mysqlconn.mysqlconn(sql)
        result=csv_output.csv_output(rows)
        return redirect('static/download/example.csv')
#########################
@app.route('/get_sku_list',methods=['GET','POST'])
def get_sku_list():
    if session["logined"] ==True:
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        print rows
        return render_template('get_each_sku_list.html',rows=rows)
    else:
        return render_template('login.html')
@app.route('/get_sku_result',methods=['GET','POST'])
def get_sku_result():
    if session["logined"] ==True:
        alist=[]
        logstash=request.values.get("logstash").strip()
        res=elk_search_detail.get_detail(logstash)
        for line in res:
            sku_id=line['key'].split('/')[-1].split('.html')[0]
            num=line['doc_count']
            sql="select sku_name from goods_sku where sku_id='%s' " % sku_id
            rows=mysqlconn_online.mysqlconn(sql)
            if len(rows)>0:
                sku_name=rows[0][0]
                alist.append([sku_id,sku_name,num])
        print alist    
        return render_template('get_sku_result.html',rows=alist)
@app.route('/get_mouth',methods=['GET','POST'])
def get_mouth():
    if session["logined"] ==True:
        return render_template('get_mouth_detail.html')

@app.route('/get_mouth_detail',methods=['GET','POST'])
def get_mouth_detail():
    alist=[]
    if session["logined"] ==True:
        logstash='logstash-nginx-access-'
        years=request.values.get("years").strip()
        mouths=request.values.get("mouths").strip()
        years=str(years)
        mouths=str(mouths)
        logstash=logstash+years+'.'+mouths+'.*'
        res=elk_search_detail.get_detail(logstash)
        for line in res:
            sku_id=line['key'].split('/')[-1].split('.html')[0]
            num=line['doc_count']
            sql="select sku_name from goods_sku where sku_id='%s' " % sku_id
            rows=mysqlconn_online.mysqlconn(sql)
            if len(rows)>0:
                sku_name=rows[0][0]
                alist.append([sku_id,sku_name,num])
        print alist
        return render_template('get_sku_result.html',rows=alist)
@app.route('/get_goods_category_list',methods=['GET','POST'])
def get_goods_category_list():
    #if session["logined"] ==True:
    if 'logined' in session:
        print session 
        sql="select logstash from logstash_list"
        rows=mysqlconn.mysqlconn(sql)
        return render_template("get_goods_category_list.html",rows=rows)
@app.route('/get_goods_category',methods=['GET','POST'])
def get_goods_category():
    if 'logined' in session:
        alist=[]
        print '*****************************************************',session
        logstash=request.values.get("logstash").strip()
        res=elk_search_list_detail.get_detail(logstash)
        for line in res:
            url=line['key']
            page=line['key'].split('/')[-1].split('.html')[0]
            num=line['doc_count']
            sql="select name from goods_category where id='%s'" % page       
            rows=mysqlconn_online.mysqlconn(sql)
            if len(rows)>0:
                name=rows[0][0]
                alist.append([page,url,name,num])
        print alist 
        return render_template('get_goods_category_result.html',rows=alist)
@app.route('/get_mouth_list_detail',methods=['GET','POST'])
def get_mouth_list_detail():
    if 'logined' in session:
        
        print '*****************************************************',session
        return render_template('get_mouth_list_detail.html')
@app.route('/get_mouth_list_detail_result',methods=['GET','POST'])
def get_mouth_list_detail_result():
    if 'logined' in session:
        alist=[]
        print '*****************************************************',session
        logstash='logstash-nginx-access-'
        years=request.values.get("years").strip()
        mouths=request.values.get("mouths").strip()
        years=str(years)
        mouths=str(mouths)
        logstash=logstash+years+'.'+mouths+'.*'
        res=elk_search_list_detail.get_detail(logstash)
        for line in res:
            url=line['key']
            page=line['key'].split('/')[-1].split('.html')[0]
            num=line['doc_count']
            sql="select name from goods_category where id='%s'" % page
            rows=mysqlconn_online.mysqlconn(sql)
            if len(rows)>0:
                name=rows[0][0]
                alist.append([page,url,name,num])
        print alist
        return render_template('get_goods_category_result.html',rows=alist)
     
    elif 'logined' not in session:
        return render_template('login.html')
@app.route('/get_order_mouth')
def get_order_mouth():
    if 'logined' in session:
        return render_template('get_order_mouth.html')

@app.route('/get_order_mouth_result',methods=['GET','POST'])
def get_order_mouth_result():
    if 'logined' in session:
        alist=[]
        print '*****************************************************',session
        logstash='logstash-nginx-access-'
        years=request.values.get("years").strip()
        mouths=request.values.get("mouths").strip()
        years=str(years)
        mouths=str(mouths)
        logstash=logstash+years+'.'+mouths+'.*'
        res=elk_search_order_mouth_aggregation.elk_order(logstash)
        num=len(res)
        return render_template('get_order_result.html',rows=res,num=num)
@app.route('/search_order_day',methods=['GET','POST'])
def search_order_day():
    if 'logined' in session:
        return render_template("search_order_day.html")

@app.route('/view_order_day_list',methods=['GET','POST'])
def view_order_day_list():
    if 'logined' in session:
        starttime=request.values.get("starttime").strip()
        endtime=request.values.get("endtime").strip()
        starttime=starttime.split("/")
        endtime=endtime.split("/")
        starttime=starttime[-1]+starttime[0]+starttime[1]+'000000000000'
        endtime=endtime[-1]+endtime[0]+endtime[1]+'235959999999'
        teshu="%Y-%m-%d %H:%i:%S"
        sql="select a.sn,a.buyer_id,b.username,a.address_name,a.address_mobile,FROM_UNIXTIME(a.system_time,'%s') as system_time,FROM_UNIXTIME(a.pay_time,'%s') as pay_time,a.pay_status,a.real_amount from `order` as a join member as b on a.buyer_id=b.id where sn >='%s' and sn <= '%s'" %(teshu,teshu,starttime,endtime)
        print sql
        rows=mysqlconn_online.mysqlconn(sql)
      
        if len(rows)>=1:
            total=int(len(rows))
            sql2="select count(*) from `order` where pay_status=1 and sn >='%s' and sn <= '%s'" %(starttime,endtime)
            res=mysqlconn_online.mysqlconn(sql2)
            payorder=int(res[0][0])
            remain=total-payorder
            return render_template('search_order_day_result.html',rows=rows,total=str(total),payorder=str(payorder),remain=str(remain))
@app.route('/get_day_order_view',methods=['GET','POST'])
def get_day_order_view():
    if 'logined' in session:
        order_sn=request.values.get("order_sn").strip()
        teshu="%Y-%m-%d %H:%i:%S"
        sql="select a.sn,b.sub_sn,a.address_name,a.address_detail,a.address_mobile,b.sku_name,b.buy_nums,b.real_price,a.pay_status,FROM_UNIXTIME(a.pay_time,'%s') as pay_time from `order` as a join order_sku as b on a.sn=b.order_sn  where order_sn='%s'" %(teshu,order_sn)
        rows=mysqlconn_online.mysqlconn(sql)
        if len(rows)>=1:
            print rows
            return render_template('get_day_order_view_result.html',rows=rows)
@app.route('/search_conditions',methods=['GET','POST'])
def search_conditions():
    if 'logined' in session:
        search_result=request.values.get("search_conditions").strip()
        teshu="%Y-%m-%d %H:%i:%S"
        sql="select a.sn,a.buyer_id,b.username,a.address_name,a.address_mobile,FROM_UNIXTIME(a.system_time,'%s') as system_time,FROM_UNIXTIME(a.pay_time,'%s') as pay_time,a.pay_status,a.real_amount from `order` as a join member as b on a.buyer_id=b.id where a.address_name='%s' or a.address_mobile='%s' or a.sn='%s'" %(teshu,teshu,search_result,search_result,search_result)
        rows=mysqlconn_online.mysqlconn(sql)
        
        
        return render_template('search_order_day_result.html',rows=rows)

@app.route('/mall_total',methods=['GET','POST'])
def mall_total():
    if 'logined' in session:
        t='%'
        location=change_overtime.change_overtime()
        #sql="select (select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as a,(select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as b,(select sum(real_amount) from `order_sub` where order_sn like '%s' and pay_status=1) as c  from `order_sub` limit 1" %(location[0:4]+t,location[0:6]+t,location+t)
        sql="select (select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as a,(select sum(real_amount) from `order_sub` where sub_sn like '%s' and pay_status=1) as b,(select sum(real_amount) from `order_sub` where order_sn like '%s' and pay_status=1) as c, (select  count(*) from  order_refund as a join `order` as b on b.sn=a.order_sn where pay_status=1 and a.status=0 and type=2) as d,(select count(*) from order_sub where delivery_status=0 and  pay_status=1 and confirm_status=2 and status=1) as e,(select count(*) from  order_sub as a join `order` as b on a.order_sn=b.sn  where a.confirm_status=0 and a.pay_status=1) as f,(select count(*) from  order_refund where type=1 and status=0) as g,(select count(*) from  goods_sku where   status=1) as h,(select count(*) from  goods_sku where   status=0) as i,(select count(*) from  goods_sku where  number<=warn_number and status=1) as j,(select count(*) from order_sub where finish_status=2) as k,(select count(*)  from member) as l,(select count(*) from `order` where status=1 and confirm_status=0 and finish_status=0) as m  from order_sub limit 1" %(location[0:4]+t,location[0:6]+t,location+t)
        rows=mysqlconn_online.mysqlconn(sql)
        
        if len(rows)>=1:
            print rows[0]
            
            years=str(rows[0][0])
            mouth=str(rows[0][1])
            today=str(rows[0][2])
            order_refund=str(rows[0][3])
            order_wait=str(rows[0][4])
            order_confirm=str(rows[0][5])
            order_refund_shenqing=str(rows[0][6])
            goods_sku_online=str(rows[0][7])
            goods_sku_waite=str(rows[0][8])
            goods_sku_reduce=str(rows[0][9])
            order_finish=str(rows[0][10])
            member=str(rows[0][11])
            unfinish_order=str(rows[0][12])
            print order_confirm,order_refund,order_wait,order_refund_shenqing,'-------------------------------%s,%s,%s' % (years,mouth,today)
            return render_template('get_shouye_total.html',years=years,mouth=mouth,today=today,order_refund=order_refund,order_wait=order_wait,order_confirm=order_confirm,order_refund_shenqing=order_refund_shenqing,goods_sku_online=goods_sku_online,goods_sku_waite=goods_sku_waite,goods_sku_reduce=goods_sku_reduce,order_finish=order_finish,member=member,unfinish_order=unfinish_order)            
            #return '%s,%s,%s' % (location[0:4]+t,location[0:6]+t,location+t)
if __name__=='__main__':
    app.run(host='0.0.0.0',debug=True)
