#!/usr/bin/python
import time
def change_overtime():
    location=time.localtime()
    if location.tm_mon<10 and location.tm_mday<10:
        gettime=str(location.tm_year)+'0'+str(location.tm_mon)+'0'+str(location.tm_mday)
    elif location.tm_mon<10 and location.tm_mday>10:
        gettime=str(location.tm_year)+'0'+str(location.tm_mon)+str(location.tm_mday)
    elif location.tm_mon>=10 and location.tm_mday>10: 
        gettime=str(location.tm_year)+str(location.tm_mon)+str(location.tm_mday)
    elif location.tm_mon>=10 and location.tm_mday<10: 
        gettime=str(location.tm_year)+str(location.tm_mon)+'0'+str(location.tm_mday)
    return gettime



if __name__=='__main__':
    print change_overtime()
