import time
def gettime(urltime):
    a=urltime
    
    #b=time.strptime(a,'%Y%m%d%H%M%S')
    b=time.mktime(time.strptime(a,'%Y%m%d%H%M%S'))
    
    
    return b
if __name__=='__main__':
    urltime='20180501112345'
    gettime(urltime)
