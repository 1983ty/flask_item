#!/bin/bash
name=`cat es_url.txt |awk -F ' ' '{print $3}' |grep logstash`
for logstash in $name
    do

     curl -XPUT http://172.19.146.77:9200/$logstash/_settings -d '{ "index" : { "max_result_window" : 100000000}}'
    done
